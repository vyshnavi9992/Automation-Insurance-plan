package PageClasses;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.aventstack.extentreports.ExtentTest;

public class CarInsurancePOM extends BaseClass{
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	String ownerName;
	String ownerEmail;
	String phoneno;
	String ownerName1;
	String ownerEmail1;
	String phoneno1;
	public CarInsurancePOM(WebDriver driver,ExtentTest logger) {
		this.driver=driver;
		this.logger=logger;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	/*******************************WEB ELEMENTS************************************/
		@FindBy(xpath="//*[@id=\"frmCar\"]/div[1]/div/div/div[6]/a[1]")
		public WebElement withoutCarNumber;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/ul/li[1]/span[1]")
		public WebElement city;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/ul/li[1]/div[2]/ul/li[1]/span")
		public WebElement rto;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/ul/div/li[2]/span")
		public WebElement brand;
		@FindBy(xpath="//*[@id=\"modelScroll\"]/li[1]/span")
		public WebElement model;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/ul/div/li[2]/span")
		public WebElement carFuelType;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div[2]/ul[1]/div/li[1]/span")
		public WebElement carVariant;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/ul/div/li[2]/span")
		public WebElement carRegistrationYear;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div[2]/div[1]/div[1]/input")
		public WebElement name;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div[2]/div[1]/div[2]/input")
		public WebElement email;
		@FindBy(id="mobileNo")
		public WebElement mobile;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div[2]/button")
		public WebElement viewPrices;
		@FindBy(xpath="//*[@id='dvVariant']/div[2]/div[1]/div[2]/div[2]")
		public WebElement emailError;
		@FindBy(xpath="/html/body/div[1]/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div[2]/div[1]/div[3]/div[2]")
		public WebElement mobileError;
		@FindBy(xpath="//*[@id=\"policy_expiry_picker_atLoading\"]/div/div[2]/table/tbody/tr[2]/td[4]/a")
		public WebElement expiryDate;
		@FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div/div[3]/div/div[1]/div[2]/div[1]/div[2]/div/div/ul/li[3]/label/div")
		public WebElement claim;
		@FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div/div[3]/div/div[1]/div[2]/div[2]/div/div[1]/img")
		public WebElement quote;
		
		/*******************READING EXCEL***********************/
		public void readExcel() throws IOException {
			File src=new File(System.getProperty("user.dir")+ "\\TestData\\CarInsuranceInput.xlsx");
			FileInputStream stream=new FileInputStream(src);
			try (XSSFWorkbook book = new XSSFWorkbook(stream)) {
				XSSFSheet sheetcar=book.getSheet("Sheet1");
				
				//Fill the form with data given in excel sheet
				ownerName=sheetcar.getRow(0).getCell(0).getStringCellValue();
				ownerEmail=sheetcar.getRow(0).getCell(1).getStringCellValue();
				long phonenumber=(long)sheetcar.getRow(0).getCell(2).getNumericCellValue();
				phoneno=String.valueOf(phonenumber);
				ownerName1=sheetcar.getRow(1).getCell(0).getStringCellValue();
				ownerEmail1=sheetcar.getRow(1).getCell(1).getStringCellValue();
				long phonenumber1=(long)sheetcar.getRow(1).getCell(2).getNumericCellValue();
				phoneno1=String.valueOf(phonenumber1);
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		/*******************WRITING EXCEL***********************/
		public void writeExcel() {
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("Car Insurance");
			sheet.createRow(0);
			sheet.getRow(0).createCell(0).setCellValue("Email Error");
			sheet.getRow(0).createCell(1).setCellValue("Mobile Error");
		}
}

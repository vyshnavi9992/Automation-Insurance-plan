package PageClasses;


import java.io.FileOutputStream;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

public class TravelInsurance extends TravelInsurancePOM {
	// constructor
	public TravelInsurance(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
	/*******************FILLING FORM1***********************/
	public void form1() throws IOException, InterruptedException {
		logger = report.createTest("Travel Insurance Plans");
		String expected = "Travel Insurance: Compare & Buy Travel Insurance Online";
		if (getTitle(expected));
		readExcel();
		selectstudent.click();
		reportPass("Selecting Student");
		destination.sendKeys(country);
		reportPass("Giving European Country Destination");
		destinationDropDown.click();
		age1.sendKeys(age_1);
		age2.sendKeys(age_2);
		reportPass("Giving age for two students");
		dateclick.click();
		startCalendar();
		endCalendar();
		proceed.click();
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(proceed));
		Thread.sleep(4000);
	}
	
	/*******************FILLING FORM2***********************/
	public void form2() throws InterruptedException {
		Select dropdown = new Select(travelGender);
		dropdown.selectByVisibleText("Ms.");
		Thread.sleep(2000);
		travelName.clear();
		travelName.sendKeys(name);
		travelMobile.clear();
		travelMobile.sendKeys(phoneno);
		travelEmail.clear();
		travelEmail.sendKeys(email);
		getFreeQuote.click();
	}
	
	/*******************FILLING FORM3***********************/
	public void form3() {
		WriteExcel();
		sumInsuranceFilter.click();
		sumInsuranceAmount.click();
		sumInsuranceApply.click();
		Select sort = new Select(sortBy);
		sort.selectByVisibleText("Price: Low to High");
		reportPass("Sorting the plans");
		takeScreenShots();
		String[] companyName1 = company1.getAttribute("class").split("Logo ");
		String[] amt1 = amount1.getText().split(" ");
		//printing the output on console
		System.out.println("insurance provider company1 " + companyName1[1] + " with amount " + amt1[1]);
		//storing the output in excel
		sheet.createRow(1);
		sheet.getRow(1).createCell(0).setCellValue(companyName1[1]);
		sheet.getRow(1).createCell(1).setCellValue(amt1[1]);
		String[] companyName2 = company2.getAttribute("class").split("Logo ");
		String[] amt2 = amount2.getText().split(" ");
		//printing the output on console
		System.out.println("insurance provider company2 " + companyName2[1] + " with amount " + amt2[1]);
		//storing the output in excel
		sheet.createRow(2);
		sheet.getRow(2).createCell(0).setCellValue(companyName2[1]);
		sheet.getRow(2).createCell(1).setCellValue(amt2[1]);
		String[] companyName3 = company3.getAttribute("class").split("Logo ");
		String[] amt3 = amount3.getText().split(" ");
		//printing the output on console
		System.out.println("insurance provider company3 " + companyName3[1] + " with amount " + amt3[1]);
		//storing the output in excel
		sheet.createRow(3);
		sheet.getRow(3).createCell(0).setCellValue(companyName3[1]);
		sheet.getRow(3).createCell(1).setCellValue(amt3[1]);
		reportPass("Displaying least three plans");
		try (FileOutputStream outputStream = new FileOutputStream("Travel Insurance Output Data.xlsx")) {
			workbook.write(outputStream);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		driver.navigate().back();
		driver.navigate().back();
	}
}

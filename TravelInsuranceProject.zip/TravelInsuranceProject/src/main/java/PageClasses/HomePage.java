package PageClasses;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;


public class HomePage extends BaseClass{
	//constructor
	public HomePage(WebDriver driver,ExtentTest logger) {
		this.driver=driver;
		this.logger=logger;
	}
	
	/*******************INSURANCE PRODUCTS LINK***********************/
	@FindBy(xpath="/html/body/cclink/div[4]/div[1]/div/ul/li[2]/a/i")
	public WebElement insuranceProducts;
	public void clickonInsuranceProducts() {
		insuranceProducts.click();
	}
	
	/*******************TRAVEL INSURANCE LINK***********************/
	@FindBy(xpath="/html/body/cclink/div[4]/div[1]/div/ul/li[2]/div/div/div[4]/ul/li[1]/a/span")
	public WebElement travelInsuranceLink;
	public TravelInsurance clickonTravelInsuranceLink() {
		travelInsuranceLink.click();
		TravelInsurance travelInsurance=new TravelInsurance(driver, logger);
		PageFactory.initElements(driver,travelInsurance);
		return travelInsurance;
	}
	
	/*******************CAR INSURANCE LINK***********************/
	@FindBy(xpath="/html/body/cclink/div[4]/div[1]/div/ul/li[2]/div/div/div[3]/h3/a")
	public WebElement carInsuranceLink;
	public CarInsurance clickonCarInsuranceLink() {
		carInsuranceLink.click();
		CarInsurance carInsurance=new CarInsurance(driver, logger);
		PageFactory.initElements(driver,carInsurance);
		return carInsurance;
	}
	
	/*******************HEALTH INSURANCE LINK***********************/
	@FindBy(xpath="/html/body/cclink/div[4]/div[1]/div/ul/li[2]/div/div/div[2]/h3/a")
	public WebElement healthInsuranceLink;
	public HealthInsurance clickonHealthInsuranceLink() {
		System.out.println(healthInsuranceLink.getText());
		HealthInsurance healthInsurance=new HealthInsurance(driver, logger);
		PageFactory.initElements(driver,healthInsurance);
		return healthInsurance;
	}
}

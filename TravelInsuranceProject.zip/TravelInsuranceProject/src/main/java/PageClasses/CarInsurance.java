package PageClasses;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import com.aventstack.extentreports.ExtentTest;

public class CarInsurance extends CarInsurancePOM {
	//constructor
	public CarInsurance(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
	/*******************WITHOUT CAR NUMBER***********************/
	public void withoutCarNumber() {
		logger = report.createTest("Car Insurance Plans");
		//String expected = "Car Insurance Online: Buy/Renew Car Insurance Policy, Get 80%* Off";
		//if (getTitle(expected));
		withoutCarNumber.click();
		reportPass("Selecting without car number");
	}
	
	/*******************FILLING CAR DETAILS***********************/
	public void carDetails() {
		city.click();
		rto.click();
		brand.click();
		model.click();
		carFuelType.click();
		carVariant.click();
		carRegistrationYear.click();
	}
	
	/*******************FILLING INVALID DETAILS***********************/
	public void invalidUserDetails() throws InterruptedException, IOException {
		readExcel();
		writeExcel();
		name.clear();
		name.sendKeys(ownerName);
		Thread.sleep(2000);
		email.clear();
		Thread.sleep(2000);
		email.sendKeys(ownerEmail);
		reportPass("Sending invalid Email");
		mobile.clear();
		mobile.sendKeys(phoneno);
		reportPass("Sending invalid Mobile No");
		viewPrices.click();
		String emailErrorMessage = emailError.getText();
		Thread.sleep(2000);
		//Printing the error message on console
		System.out.println(emailErrorMessage);
		reportPass("Displaying email error message");
		//Storing the error message in excel
		sheet.createRow(1);
		sheet.getRow(1).createCell(0).setCellValue(emailErrorMessage);
		String mobileErrorMessage = mobileError.getText();
		//Printing the error message on console
		System.out.println(mobileErrorMessage);
		reportPass("Displaying mobile error message");
		//Storing the error message in excel
		sheet.getRow(1).createCell(1).setCellValue(mobileErrorMessage);
		reportFail("Invalid Email and mobile no");
		try (FileOutputStream outputStream = new FileOutputStream("Car Insurance Output Data.xlsx")) {
			workbook.write(outputStream);
			workbook.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/*******************FILLING VALID DETAILS***********************/
	public void validUserDetails() {
		name.clear();
		name.sendKeys(ownerName1);
		reportPass("Sending valid Name");
		email.clear();
		email.sendKeys(ownerEmail1);
		reportPass("Sending valid Email");
		mobile.clear();
		mobile.sendKeys(phoneno1);
		reportPass("Sending valid Mobile No");
		viewPrices.click();
		reportPass("Sending valid Details");
		expiryDate.click();
		reportPass("Sending expiry date");
		claim.click();
		reportPass("Sending claim details");
		//taking screenshot for the car insurance quote
		takeScreenShots();
		reportPass("Retrieving car insurance quote");
		driver.navigate().back();
		driver.navigate().back();
		driver.navigate().back();
	}
}

package PageClasses;

import java.io.File;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Utilities.DateUtil;
import Utilities.ExtentReportManager;

import org.testng.Assert;

public class BaseClass {
	public WebDriver driver;
	public WebDriverWait wait;
	public ExtentReports report = ExtentReportManager.getReportInstance();
	public ExtentTest logger;
	public static Properties prop = new Properties();

	/*******************INVOKING BROWSERS***********************/
	public void invokeBrowser(String browserName) {
		try {
			if (browserName.equalsIgnoreCase("Chrome")) {
				System.setProperty("webdriver.chrome.driver",
						"..\\TravelInsuranceProject\\src\\test\\resources\\drivers\\chromedriver.exe");
				driver = new ChromeDriver();
			} else if (browserName.equalsIgnoreCase("Firefox")) {
				System.setProperty("webdriver.gecko.driver",
						"..\\TravelInsuranceProject\\src\\test\\resources\\drivers\\geckodriver.exe");
				driver = new FirefoxDriver();
			}else if (browserName.equalsIgnoreCase("Edge")) {
				System.setProperty("webdriver.edge.driver",
						"..\\TravelInsuranceProject\\src\\test\\resources\\drivers\\geckodriver.exe");
				driver = new EdgeDriver();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/********************LOADING CONFIG FILE**************************/
	public void loadConfig() throws IOException {
		//getting the property file
		String filelocation = System.getProperty("user.dir")+"\\src\\test\\resources\\ObjectRepository\\config.property";
		File file = new File(filelocation);
		FileInputStream fileinput = new FileInputStream(file);
		//loading the config.properties file
		prop.load(fileinput);
	}

	/*******************FLUSHING REPORTS***********************/
	public void flushReports() {
		//flushing report
		report.flush();
		//closing driver
		driver.close();
	}

	/*******************OPENING URL***********************/
	public HomePage openUrl() throws IOException {
		//loading config
		loadConfig();
		driver.manage().window().maximize();
		//getting URL from config file
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		HomePage homepage = new HomePage(driver, logger);
		PageFactory.initElements(driver, homepage);
		return homepage;
	}

	/*******************CHECKING TITLE OF THE PAGE***********************/
	public boolean getTitle(String expectedTitle) {
		try {
			//checking title
			Assert.assertEquals(driver.getTitle(), expectedTitle);
			reportPass("Actual Title : " + driver.getTitle() + " - equals to Expected Title : " + expectedTitle);
			return true;
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
		return false;
	}

	/*******************FAILURE REPORT***********************/
	public void reportFail(String reportString) {
		logger.log(Status.FAIL, reportString);
		takeScreenShots();
		//Assert.fail(reportString);
	}

	/*******************PASS REPORT***********************/
	public void reportPass(String reportString) {
		logger.log(Status.PASS, reportString);
	}
	
	/*******************INFO REPORT***********************/
	public void reportInfo(String reportString) {
		logger.log(Status.INFO, reportString);
	}

	/*******************TAKING SCREENSHOTS***********************/
	public void takeScreenShots() {
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		File sourceFile = takeScreenShot.getScreenshotAs(OutputType.FILE);

		File destFile = new File(System.getProperty("user.dir") + "/ScreenShots/" + DateUtil.getTimeStamp() + ".png");
		try {
			FileUtils.copyFile(sourceFile, destFile);
			logger.addScreenCaptureFromPath(
					System.getProperty("user.dir") + "/ScreenShots/" + DateUtil.getTimeStamp() + ".png");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

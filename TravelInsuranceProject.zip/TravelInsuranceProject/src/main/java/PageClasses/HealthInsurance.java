package PageClasses;

import java.io.FileOutputStream;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.aventstack.extentreports.ExtentTest;

public class HealthInsurance extends BaseClass{
	//constructor
	public HealthInsurance(WebDriver driver,ExtentTest logger) {
		this.driver=driver;
		this.logger=logger;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath="/html/body/cclink/div[4]/div[1]/div/ul/li[2]/div/div/div[2]/ul/li/a/span")
	public List<WebElement> menuList;
	
	/*******************HEALTH INSURANCE MENU ITEMS***********************/
	public void HealthInsuranceMenuItems() throws InterruptedException {
		logger=report.createTest("Health Insurance Plans");
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Health Insurance");
		sheet.createRow(0);
		sheet.getRow(0).createCell(0).setCellValue("Health Insurance Menu");
		sheet.createRow(1);
		//storing the menu into LIST
		List<WebElement> list=menuList;
		reportPass("Storing menu items in list");
		int s=list.size();
		for(int i=0;i<s;i++) {
			//Printing the menu on console
			System.out.println(list.get(i).getText());
			String menu=list.get(i).getText();
			//Storing the menu in excel
			sheet.createRow(i+1);
			sheet.getRow(i+1).createCell(0).setCellValue(menu);
		}
		reportPass("Displaying List of menu items");
		try (FileOutputStream outputStream = new FileOutputStream("Health Insurance Output Data.xlsx")) {
			workbook.write(outputStream);
			workbook.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

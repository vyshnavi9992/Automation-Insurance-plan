package PageClasses;

import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.ExtentTest;

public class TravelInsurancePOM extends BaseClass{
	String country;
	String age_1;
	String age_2;
	String name;
	String phoneno;
	String email;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	//Constructor
	public TravelInsurancePOM(WebDriver driver, ExtentTest logger) {
		this.driver=driver;
		this.logger=logger;
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	/****************************************WEB ELEMENTS**************************************************/
		@FindBy(className="monthselect")
		public WebElement selectmonth;
		@FindBy(xpath="//td[text()='3']")
		public WebElement selectday1;
		@FindBy(xpath="//*[@id=\"navigatorType\"]/body/div[9]/div[2]/div[1]/table/tbody/tr[2]/td[4]")
		public WebElement selectday2;
		@FindBy(xpath="//*[@id=\"topForm\"]/section/div[2]/article/ul/li[3]/a")
		public WebElement selectstudent;
		@FindBy(id="destination-autocomplete")
		public WebElement destination;
		@FindBy(xpath="/html/body/ul/li")
		public WebElement destinationDropDown;
		@FindBy(id="memage1")
		public WebElement age1;
		@FindBy(id="memage2")
		public WebElement age2;
		@FindBy(id="startdate")
		public WebElement dateclick;
		@FindBy(xpath="/html/body/div[2]/section/div[2]/section/div[2]/div[2]/div[1]/div[1]/div/a")
		public WebElement proceed;
		@FindBy(id="travelgender")
		public WebElement travelGender;
		@FindBy(id="travelname")
		public WebElement travelName;
		@FindBy(id="travelmobile")
		public WebElement travelMobile;
		@FindBy(id="travelemail")
		public WebElement travelEmail;
		@FindBy(xpath="/html/body/div[2]/section/div[2]/section/div[2]/div[2]/div[1]/div[2]/div/a[2]")
		public WebElement getFreeQuote;
		@FindBy(xpath="//*[@id='sumInsurer-filter']")
		public WebElement sumInsuranceFilter;
		@FindBy(xpath="//*[@id='sum_modal']/div[2]/div[1]/span[1]")
		public WebElement sumInsuranceAmount;
		@FindBy(xpath="//*[@id='sum_modal']/div[2]/div[2]/button[2]")
		public WebElement sumInsuranceApply;
		@FindBy(xpath="//*[@id='root']/main/div/div[2]/div/div[1]/div[4]/ul/li[5]/div/select")
		public WebElement sortBy;
		@FindBy(xpath="//*[@id=\'root\']/main/div/div[2]/div/div[1]/div[8]/div/div/div[1]/div[1]/div")
		public WebElement company1;
		@FindBy(id="74")
		public WebElement amount1;
		@FindBy(xpath="//*[@id=\'root\']/main/div/div[2]/div/div[1]/div[9]/div/div/div[1]/div[1]/div")
		public WebElement company2;
		@FindBy(id="17")
		public WebElement amount2;
		@FindBy(xpath="//*[@id=\'root\']/main/div/div[2]/div/div[1]/div[10]/div/div/div[1]/div[1]/div")
		public WebElement company3;
		@FindBy(id="304")
		public WebElement amount3;
		
		/*******************START CALENDAR***********************/
		public void startCalendar() {
			Select month=new Select(selectmonth);
			month.selectByVisibleText("May");
			selectday1.click();
		}
		
		/*******************END CALENDAR***********************/
		public void endCalendar() {
			Select month=new Select(selectmonth);
			month.selectByVisibleText("May");
			selectday2.click();
		}
		
		/*******************READING EXCEL***********************/
		public void readExcel() throws IOException {
			File src = new File(System.getProperty("user.dir") + "\\TestData\\TravelInsuranceInput.xlsx");
			FileInputStream stream = new FileInputStream(src);
			try (XSSFWorkbook book = new XSSFWorkbook(stream)) {
				XSSFSheet sheettravel = book.getSheet("Sheet1");

				// Fill the form with data given in excel sheet
				country = sheettravel.getRow(0).getCell(0).getStringCellValue();
				// String age_1=String.valueOf(sheettravel.getRow(0).getCell(1));
				// String age_2=String.valueOf(sheettravel.getRow(0).getCell(2));
				long userAge_1 = (long) sheettravel.getRow(0).getCell(1).getNumericCellValue();
				age_1 = String.valueOf(userAge_1);
				long userAge_2 = (long) sheettravel.getRow(0).getCell(2).getNumericCellValue();
				age_2 = String.valueOf(userAge_2);
				name = sheettravel.getRow(0).getCell(3).getStringCellValue();
				long phonenumber = (long) sheettravel.getRow(0).getCell(4).getNumericCellValue();
				phoneno = String.valueOf(phonenumber);
				email = sheettravel.getRow(0).getCell(5).getStringCellValue();
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		/*******************WRITING EXCEL***********************/
		public void WriteExcel() {
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("Travel Insurance");
			sheet.createRow(0);
			sheet.getRow(0).createCell(0).setCellValue("Company Name");
			sheet.getRow(0).createCell(1).setCellValue("Amount");
		}
}

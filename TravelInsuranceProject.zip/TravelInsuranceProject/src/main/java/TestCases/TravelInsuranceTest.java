package TestCases;

import java.io.IOException;


import org.testng.annotations.Test;

import PageClasses.BaseClass;
import PageClasses.CarInsurance;
import PageClasses.HealthInsurance;
import PageClasses.HomePage;
import PageClasses.TravelInsurance;

public class TravelInsuranceTest extends BaseClass{

	public static BaseClass base;
	public static HomePage homePage;
	public static TravelInsurance travelInsurance;
	public static CarInsurance carInsurance;
	
	/*******************CALLING BASE FUNCTIONS***********************/
	@Test(groups = "Smoke")
	public void baseFunctions() throws InterruptedException, IOException {
		logger=report.createTest("Travel Insurance Project");
		base=new BaseClass();
		base.loadConfig();
		base.invokeBrowser(prop.getProperty("browser1"));
		homePage=base.openUrl();
		reportInfo("Opening Browser");
	}
	
	/*******************TRAVEL INSURANCE FORM1***********************/
	@Test(groups = "Smoke", dependsOnMethods = "baseFunctions")
	public void travelInsuranceForm1() throws InterruptedException, IOException {
		homePage.clickonInsuranceProducts();
		reportInfo("clicking on Insurance Products");
		travelInsurance=homePage.clickonTravelInsuranceLink();
		reportInfo("clicking on Travel Insurance Link");
		travelInsurance.form1();
	}
	
	/*******************TRAVEL INSURANCE FORM2***********************/
	@Test(groups = "Smoke",dependsOnMethods = "travelInsuranceForm1")
	public void travelInsuranceForm2() throws InterruptedException {
		travelInsurance.form2();
	}
	
	/*******************TRAVEL INSURANCE FORM3***********************/
	@Test(groups = "Regression",dependsOnMethods = "travelInsuranceForm2")
	public void travelInsuranceForm3() throws InterruptedException {
		travelInsurance.form3();
		reportPass("Getting travel Insurance plans");
	}
	
	/*******************CAR INSURANCE WITHOUT CAR NUMBER***********************/
	@Test(groups = {"Smoke","Regression"},dependsOnMethods = "travelInsuranceForm3")
	public void carInsuranceCarNumber() throws InterruptedException, IOException {
		homePage.clickonInsuranceProducts();
		reportInfo("clicking on Insurance Products");
		carInsurance=homePage.clickonCarInsuranceLink();
		reportInfo("clicking on Car Insurance Link");
		carInsurance.withoutCarNumber();
		reportPass("Getting Car Insurance Error Message");
	}
	
	/*******************CAR INSURANCE CAR DETAILS***********************/
	@Test(groups = "Regression",dependsOnMethods = "carInsuranceCarNumber")
	public void carInsuranceCarDetails() throws InterruptedException {
		carInsurance.carDetails();
	}
	
	/*******************CAR INSURANCE INVALID DETAILS***********************/
	@Test(groups = "Regression",dependsOnMethods = "carInsuranceCarDetails")
	public void carInsuranceInvalidDetails() throws InterruptedException, IOException {
		carInsurance.invalidUserDetails();
	}
	
	/*******************CAR INSURANCE VALID DETAILS***********************/
	@Test(groups = "Regression",dependsOnMethods = "carInsuranceInvalidDetails")
	public void carInsuranceValidDetails() throws InterruptedException {
		carInsurance.validUserDetails();
	}
	
	/*******************HEALTH INSURANCE***********************/
	@Test(groups = {"Smoke","Regression"},dependsOnMethods = "carInsuranceValidDetails")
	public void healthInsurance() throws InterruptedException, IOException {
		homePage.clickonInsuranceProducts();
		reportInfo("clicking on Insurance Products");
		HealthInsurance healthInsurance=homePage.clickonHealthInsuranceLink();
		reportInfo("clicking on Health Insurance Link");
		healthInsurance.HealthInsuranceMenuItems();
		reportPass("Getting Health Insurance Menu Items");
		base.flushReports();
	}
}
